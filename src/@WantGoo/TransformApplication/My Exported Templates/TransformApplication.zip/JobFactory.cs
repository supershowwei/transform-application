﻿using System;
using $safeprojectname$.Jobs;

namespace $safeprojectname$
{
    internal static class JobFactory
    {
        public static IJob GenerateJob(string name)
        {
            switch (name)
            {
                case "TestJob":
                    return new TestJob(name);
                default:
                    throw new NotSupportedException();
            }
        }
    }
}