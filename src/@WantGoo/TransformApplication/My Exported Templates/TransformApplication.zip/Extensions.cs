﻿using System.Windows.Forms;

namespace $safeprojectname$
{
    internal static class Extensions
    {
        public static void InvokeIfNecessary(this Control control, MethodInvoker action)
        {
            if (control.InvokeRequired)
            {
                control.Invoke(action);
            }
            else
            {
                action();
            }
        }
    }
}